# ppguard
# pkg install php
# git clone https://github.com/dede-kuntoro/pp-guard
# cd ppguard
# php guard.php
